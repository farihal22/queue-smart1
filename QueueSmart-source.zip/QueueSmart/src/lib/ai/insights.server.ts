import { createOpenAI } from "@ai-sdk/openai";
import { streamText } from "ai";
import { createLovableAiGatewayRunIdFetch, withLovableAiGatewayRunIdHeader } from "./run-id.server";

const INSTRUCTIONS = `You are an operations analyst for QueueSmart, a branch queue management system.
A branch manager asks a question about today's queue activity. You receive a JSON snapshot of services, counters and tickets
(times are epoch ms; st = waiting | called | done; sid = service id; to = counter number).
Answer concisely in plain text (no markdown tables). First summarize the relevant data with concrete numbers,
then give 2-4 practical operational suggestions (staffing, counter assignments, service mix). If data is thin, say so.`;

export async function handleInsights(request: Request) {
  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) return new Response("AI is not configured.", { status: 500 });
  let body: { question?: unknown; snapshot?: unknown };
  try { body = await request.json(); } catch { return new Response("Invalid request.", { status: 400 }); }
  const question = typeof body.question === "string" ? body.question.trim().slice(0, 1000) : "";
  if (!question) return new Response("Please type a question.", { status: 400 });
  const snapshot = JSON.stringify(body.snapshot ?? {}).slice(0, 60000);

  const runIdFetch = createLovableAiGatewayRunIdFetch();
  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });
  const result = streamText({
    model: provider.responses("openai/gpt-6-astra"),
    system: INSTRUCTIONS,
    messages: [{ role: "user", content: `Queue snapshot:\n${snapshot}\n\nManager's question: ${question}` }],
    abortSignal: request.signal,
    maxRetries: 0,
    providerOptions: {
      openai: { store: false, forceReasoning: true, reasoningEffort: "low", include: ["reasoning.encrypted_content"] },
    },
    onError: ({ error }) => console.error("insights AI error", error),
  });
  const res = result.toTextStreamResponse({ headers: { "Cache-Control": "no-cache, no-transform" } });
  return withLovableAiGatewayRunIdHeader(res, runIdFetch);
}
