import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "QueueSmart – Smart Queue Management" },
      { name: "description", content: "QueueSmart smart queue management." },
      { property: "og:title", content: "QueueSmart – Smart Queue Management" },
      { property: "og:description", content: "QueueSmart smart queue management." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/queuesmart.html"
      title="QueueSmart"
      style={{ position: "fixed", inset: 0, width: "100%", height: "100%", border: 0 }}
    />
  );
}
