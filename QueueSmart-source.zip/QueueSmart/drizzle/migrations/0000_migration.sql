create type public.app_role as enum ('customer','staff','manager');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null default '',
  created_at timestamptz not null default now()
);
grant select on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  approved boolean not null default true,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.is_approved_manager(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.user_roles where user_id=_uid and role='manager' and approved)
$$;

create policy "own profile" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_approved_manager(auth.uid()));
create policy "own role" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.is_approved_manager(auth.uid()));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare r public.app_role; ok boolean := true;
begin
  r := case new.raw_user_meta_data->>'role' when 'staff' then 'staff'::public.app_role when 'manager' then 'manager'::public.app_role else 'customer'::public.app_role end;
  if r = 'manager' then
    perform pg_advisory_xact_lock(424242);
    ok := not exists(select 1 from public.user_roles where role='manager' and approved);
  end if;
  insert into public.profiles(id, full_name, email) values (new.id, coalesce(left(new.raw_user_meta_data->>'full_name',100),''), coalesce(new.email,''));
  insert into public.user_roles(user_id, role, approved) values (new.id, r, ok);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.pending_managers()
returns table(user_id uuid, full_name text, email text) language sql stable security definer set search_path = public as $$
  select p.id, p.full_name, p.email from public.user_roles r join public.profiles p on p.id=r.user_id
  where r.role='manager' and not r.approved and public.is_approved_manager(auth.uid()) order by r.created_at
$$;
create or replace function public.decide_manager(_uid uuid, _approve boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_approved_manager(auth.uid()) then raise exception 'not allowed'; end if;
  if _approve then update public.user_roles set approved=true where user_id=_uid and role='manager';
  else delete from auth.users where id=_uid and exists(select 1 from public.user_roles where user_id=_uid and role='manager' and not approved); end if;
end $$;
revoke execute on function public.pending_managers() from anon, public;
revoke execute on function public.decide_manager(uuid, boolean) from anon, public;
grant execute on function public.pending_managers() to authenticated;
grant execute on function public.decide_manager(uuid, boolean) to authenticated;
grant execute on function public.is_approved_manager(uuid) to authenticated;

create table public.queue_state (
  id int primary key,
  data jsonb not null,
  version bigint not null default 0,
  updated_at timestamptz not null default now()
);
grant select, update on public.queue_state to authenticated;
grant all on public.queue_state to service_role;
alter table public.queue_state enable row level security;
create policy "signed in read" on public.queue_state for select to authenticated using (true);
create policy "signed in update" on public.queue_state for update to authenticated using (true) with check (true);
insert into public.queue_state(id, data) values (1, '{"services":[{"id":"s1","name":"Account opening","p":"A","avg":8},{"id":"s2","name":"Cash and deposits","p":"B","avg":4},{"id":"s3","name":"Customer care","p":"C","avg":6}],"counters":[{"id":1,"t":null,"sv":["s1","s3"]},{"id":2,"t":null,"sv":["s2","s3"]},{"id":3,"t":null,"sv":["s1","s2"]}],"tickets":[],"seq":{}}');
alter publication supabase_realtime add table public.queue_state;